package lab5;

public class Application  {
	
	static public void main(String[] args) throws InterruptedException {
		Fifo f1=new Fifo();
		
		Producer p1=new Producer("p",1000,f1);
		Producer p2=new Producer("p",1000,f1);
		Producer p3=new Producer("p",1000,f1);
		
		Thread t1=new Thread(p1);
		Thread t2=new Thread(p2);
		Thread t3=new Thread(p3);
		
		Consumer c1=new Consumer("s",100,f1);
		Consumer c2=new Consumer("s",100,f1);
		Consumer c3=new Consumer("s",100,f1);
		Consumer c4=new Consumer("s",100,f1);
		
		 
		t1.start();
		t2.start();
		t3.start();
		
		c1.start();
		c2.start();
		c3.start();
		c4.start();
	}
}
