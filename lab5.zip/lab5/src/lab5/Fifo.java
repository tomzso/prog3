package lab5;


import java.util.LinkedList;

public class Fifo {

	public LinkedList<String> array=new LinkedList<>();
	
	public synchronized void put(String s) throws InterruptedException {
		System.out.println("Put " + Thread.currentThread().getId());
		while(array.size()>=10) {
			this.wait();
		}
		array.add(s);
		this.notify();
		System.out.println("produced "+array.getLast()+" "+System.currentTimeMillis()%100000);
	}
	public synchronized String get() throws InterruptedException {
		System.out.println("Get " + Thread.currentThread().getId());
		while(array.size()<=0) {
			this.wait();
		}
		String s=array.getFirst();
		array.removeFirst();
		this.notify();
		
		return s;
			

	}
}
