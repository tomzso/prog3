package lab5;

public class Producer implements Runnable  {
	String string;
	int delay;
	Fifo fifo;
	
	public Producer(String s,int d, Fifo f) {
		string=s;
		delay=d;
		fifo=f;
	}
	
	
	public void go() throws InterruptedException {
		int i=0;
		while(true) {
			//if(i==0) Thread.sleep(delay);
			//System.out.println(string+" "+(i++)+" "+System.currentTimeMillis()%100000);
			//System.out.println("produced "+string+" "+(i++)+" " +System.currentTimeMillis()%100000);
			
			fifo.put(string+" "+(i++));

			
			Thread.sleep(delay);
		
		}
	}
	
	@Override
	public void run() {
		try {
			go();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void start() {
		// TODO Auto-generated method stub
		
	}
}
