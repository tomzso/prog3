package lab5;

public class Consumer extends Thread{
	Fifo fifo;
	String string;
	int number;
	
	public Consumer(String s,int n,Fifo f) {
		fifo=f;
		string=s;
		number=n;
		
	}
	public void run() {
		while(true) {
			
			try {
				 
				String s = fifo.get();
				System.out.println("consumed "+string+" "+s+" "+System.currentTimeMillis()%100000);
				Thread.sleep(number);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
		}
		
	}
	
}
