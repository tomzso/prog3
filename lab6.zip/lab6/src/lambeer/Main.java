package lambeer;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;






public class Main {
	static public ArrayList<Beer> arraylist=new ArrayList<Beer>();
	static public HashMap<String, Comparator<Beer>> comps=new HashMap<String, Comparator<Beer>>();
	static {
		Comparator<Beer> name=Comparator.comparing(Beer::getName);
		Comparator<Beer> style=Comparator.comparing(Beer::getStyle);
		Comparator<Beer> strength=Comparator.comparing(Beer::getStength);
		comps.put("name", name);
		comps.put("style", style);
		comps.put("strength", strength);
	}
	

	static protected void exit() {
		System.exit(0);
	}
	static protected void list(String[] array) {
		Comparator<Beer> cmp=comps.get("name");
		if(array.length==2) {
			if(comps.containsKey(array[1])) {
				cmp=comps.get(array[1]);
			}
			
			
			/*
			if(array[1].equals("name")) {
				Collections.sort(arraylist,
						(b1,b2) -> b1.getName().compareTo(b2.getName()));
			}else if(array[1].equals("style")){
				Collections.sort(arraylist,
						(b1,b2) -> b1.getStyle().compareTo(b2.getStyle()));
			}else if(array[1].equals("strength")){
				Collections.sort(arraylist,
						(b1,b2) -> (int)(b1.getStength()-b2.getStength())
						);
			}*/
			
		}
		Collections.sort(arraylist,cmp);
		
		for (int i=0;i<arraylist.size();i++) {
			System.out.println(arraylist.get(i).toString());
		}
	}
	static protected void add(String[] array) {
		arraylist.add(new Beer(array[1],array[2],Double.parseDouble(array[3])));
	}	
	static protected void save(String[] array) throws IOException {
		ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(array[1]));
		out.writeObject(arraylist);
		out.close();
	}	
	static protected void load(String[] array) throws IOException, ClassNotFoundException{
		ObjectInputStream in=new ObjectInputStream(new FileInputStream(array[1]));
		arraylist=(ArrayList<Beer>)in.readObject();
		in.close();
	}	
	static protected void search(String[] array) {
		for(Beer b: arraylist) {
			if(b.getName().equals(array[1]))
				System.out.println(b.toString());
		}
	}
	static protected void find(String[] array) {
		for(int i=1;i<array.length;i++) {
			for(Beer b: arraylist) {
				if(b.getName().contains(array[i]))
					System.out.println(b.toString());
			}
		}
	}
	static protected void delete(String[] array) {
		Collections.sort(arraylist,(b1,b2) -> b1.getName().compareTo(b2.getName()));
		arraylist.remove(Collections.binarySearch(arraylist, new Beer(array[1], null, 0), (b1,b2) -> b1.getName().compareTo(b2.getName())));
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		HashMap<String,Command> commands=new HashMap<String,Command>();
		commands.put("list", Main::list);
		commands.put("add", Main::add);
		commands.put("save", Main::save);
		commands.put("load", Main::load);
		commands.put("search", Main::search);
		commands.put("find", Main::find);
		commands.put("delete", Main::delete);
		
		
		
		arraylist.add(new Beer("Uc","easy",6.4));
		arraylist.add(new Beer("Rt","medium",3.1));
		arraylist.add(new Beer("Hard","hard",9.1));
		arraylist.add(new Beer("Premium","soft",0.000002));
		
		System.out.println(arraylist.get(0).toString());
		System.out.println(arraylist.get(1).toString());
		System.out.println(arraylist.get(2).toString());
		System.out.println(arraylist.get(3).toString());
		
		while(true) {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s=br.readLine();
			String[] cmd=s.split(" ");
			
			if(commands.containsKey(cmd[0])) {
				commands.get(cmd[0]).execute(cmd);
			}else {
				System.out.println("Command not found.");
			}
			

			
			System.out.println(cmd[0]+", tomb merete: "+cmd.length);
			
		}
		
		
	}
}

