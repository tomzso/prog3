module lab6 {
}